Emmanuel Arias Soto
emmanuel1412@gmail.com

Version: 1.0
Implementacion en Python y el modulo pygame del juego Hnefatafl, un ajedrez vikingo.

Cambios en la version 1.0:
+ Conservadas las clases Main, Grafico y Tablero. Tablero ahora maneja la logica usando instancias de
la clase Ficha y de Blanca, Negra y Rey que heredan de la primera, ahora las operaciones principales
las realizan las fichas. Esto para mas eventualmente implementar un sistema PvIA
+ Uso de normas de escritura propias de Python para mayor legibilidad
+ Mejora en algoritmos de las operaciones del juego.


Las reglas para este juego se pueden encontrar aqui http://www.gamecabinet.com/history/Hnef.html